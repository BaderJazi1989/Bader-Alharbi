
import org.opennebula.client.Client;
import org.opennebula.client.OneResponse;
import org.opennebula.client.vm.VirtualMachine;
import org.opennebula.client.host.Host;
import org.opennebula.client.host.HostPool;
import org.opennebula.client.vm.VirtualMachinePool;

import java.util.concurrent.TimeUnit;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
//import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

public class firstfit {
	//global variable to store responses
	static OneResponse rc;
	//global variable to store VM information
	static VirtualMachine vm;
	//global variable to store host ID
	static int currentHostID = -1;
	
	
	public static void main(String[] args) {
        Client oneClient;
        String passwd;
		
		//get username and password
		String username = System.getProperty("user.name");
        passwd = new String(System.console().readPassword("[%s]", "Password:"));
        
        try {
			//connect to OpenNebula
            oneClient = new Client(username + ":" + passwd, "https://csgate1.leeds.ac.uk:2633/RPC2");
            
            //template of VM to be deployed
            String vmTemplate =
                    "CPU=\"0.1\"\n"
                            + "SCHED_DS_REQUIREMENTS=\"ID=101\"\n"
                            + "NIC=[\n"
                            + "\tNETWORK_UNAME=\"oneadmin\",\n"
                            + "\tNETWORK=\"vnet1\" ]\n"
                            + "LOGO=\"images/logos/linux.png\"\n"
                            + "DESCRIPTION=\"A ttylinux instance with VNC and network context scripts, available for testing purposes. In raw format.\"\n"
                            + "DISK=[\n"
                            + "\tIMAGE_UNAME=\"oneadmin\",\n"
                            + "\tIMAGE=\"ttylinux Base\" ]\n"
                            + "SUNSTONE_NETWORK_SELECT=\"YES\"\n"
                            + "SUNSTONE_CAPACITY_SELECT=\"YES\"\n"
                            + "MEMORY=\"128\"\n"
                            + "HYPERVISOR=\"kvm\"\n"
                            + "GRAPHICS=[\n"
                            + "\tLISTEN=\"0.0.0.0\",\n"
                            + "\tTYPE=\"VNC\" ]\n";
                            
            //deploy VM and store deployment result in OneResponse object rc
            rc = VirtualMachine.allocate(oneClient, vmTemplate);
            
            //check if there is an error in deployment
            if (rc.isError()) {
                System.out.println("[!]Allocation failed: " + rc.getErrorMessage());
                throw new Exception(rc.getErrorMessage());
            }
	
			//the response message is the newly deployed VM's ID
			int newVMID = Integer.parseInt(rc.getMessage());
            System.out.println("[+]ok, ID " + newVMID + ".");
			
			//reate a representation for the newly deployed VM using the returned VM ID
            vm = new VirtualMachine(newVMID, oneClient);
			
			//finding first available host
			int thisHostID = -1;
			try{
				HostPool thisPool = new HostPool( oneClient );
				thisPool.info();
				for(Host thisHost: thisPool){
					thisHost.info();
					double thisHostCPU = (Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/USED_CPU")) / Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/MAX_CPU"))) * 100;
					if(thisHost.isEnabled())	
					{
						thisHostID = Integer.parseInt(thisHost.xpath("/HOST/ID"));
						break;
					}
			}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			//deploying VM
            rc = vm.deploy(thisHostID);
			
			if (rc.isError()) {
                System.out.println("[!]Deploying failed: " + rc.getErrorMessage());
                throw new Exception(rc.getErrorMessage());
            }
            
			rc = vm.info();
            
            if(rc.isError())
				throw new Exception( rc.getErrorMessage() );

			System.out.println("VM deployed with id is      " + vm.getId());
			

			// SLA manager
			//////////////
			
			try{
				int newTargetHost = -1;
				HostPool thisPool = new HostPool( oneClient );
				thisPool.info();
				for(Host thisHost: thisPool){
					thisHost.info();
					double thisHostCPU = (Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/USED_CPU")) / Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/MAX_CPU"))) * 100;
					thisHostID = Integer.parseInt(thisHost.xpath("/HOST/ID"));
					if(thisHost.isEnabled() && thisHostCPU < 0.85)	
					{
						//TimeUnit.MINUTES.sleep(1);
						//System.out.println("I have waited 1 minutes for host " + thisHostID);
						
						//check again if threshold still reached before implementing scheduling algorithm
						if(thisHost.isEnabled())	
						{
							
							//scheduling algorithm implementation
							try{
								HostPool existingPool = new HostPool( oneClient );
								existingPool.info();
								for(Host existingHost: existingPool){
									existingHost.info();
									int targetHostID = Integer.parseInt(existingHost.xpath("/HOST/ID"));
									if(existingHost.isEnabled() && thisHostID != targetHostID)	
									{
										//thisHostID = Integer.parjavaseInt(thisHost.xpath("/HOST/ID"));
										newTargetHost = targetHostID;
										break;
									}
							}
							}catch(Exception e){
								e.printStackTrace();
							}
							
							/*
							double thisHostCPUUsage = (Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/USED_CPU")) / Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/MAX_CPU"))) * 100;
							double thisHostMemoryUsage = (Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/USED_MEM")) / Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/MAX_MEM"))) * 100;
							double thisHostDiskUsage = (Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/USED_DISK")) / Double.parseDouble(thisHost.xpath("/HOST/HOST_SHARE/MAX_DISK"))) * 100;
							double thisHostCost = (thisHostCPUUsage * 0.9) + (thisHostMemoryUsage * 0.05) + (thisHostDiskUsage * 0.05);
							int minimumHostID = thisHostID;
							double minimumHostCost = thisHostCost;
							//Host minimumCostHost = thistHost;
							//looking for best host to migrate busiest VM to
							for(Host targetHost: thisPool)
							{
								targetHost.info();
								int targetHostID = Integer.parseInt(targetHost.xpath("/HOST/ID"));
								double targetHostCPUUsage = (Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/USED_CPU")) / Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/MAX_CPU"))) * 100;
								double targetHostMemoryUsage = (Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/USED_MEM")) / Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/MAX_MEM"))) * 100;
								double targetHostDiskUsage = (Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/USED_DISK")) / Double.parseDouble(targetHost.xpath("/HOST/HOST_SHARE/MAX_DISK"))) * 100;
								double targetHostCost = (targetHostCPUUsage * 0.9) + (targetHostMemoryUsage * 0.05) + (targetHostDiskUsage * 0.05);
								
								if ( targetHost.isEnabled() && (targetHost != thisHost) && (targetHostCost < minimumHostCost) )
								{
									minimumHostID = targetHostID;
									minimumHostCost = targetHostCost;
									//minimumCostHost = targetHost;
								}
							}*/
							//migrate VM to best host
							//finding busiest VM in 
							rc = thisHost.info();
							String xml = rc.getMessage();
							DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
							DocumentBuilder builder = factory.newDocumentBuilder();
							Document doc = builder.parse(new InputSource(new StringReader(xml)));
							XPathFactory xPathfactory = XPathFactory.newInstance();
							XPath xpath = xPathfactory.newXPath();
							NodeList list = (NodeList) xpath.evaluate("/HOST/VMS/ID", doc, XPathConstants.NODESET);
							VirtualMachinePool vmPool = new VirtualMachinePool(oneClient);
							vmPool.info();
							int vmID,minID = -1;
							double vmCPU, minCPU = 0.0;
							VirtualMachine busiestVM = null;
							for (int i = 0; i < list.getLength(); ++i)
							{
								Node node = list.item(i);
								vmID = Integer.parseInt(node.getFirstChild().getNodeValue());
								//create VM pool and find this VM by its ID
								//
								VirtualMachine vm = vmPool.getById(vmID);
								if (vm != null)
								{
									vmCPU = (Double.parseDouble(vm.xpath("/VM_POOL/VM/TEMPLATE/CPU")));
									//VM id Returned having maximum CPU utilization, This VM will be migrated to new host
									if (vmCPU >= minCPU)
									{
										minCPU = vmCPU;
										busiestVM = vm;
										minID = vmID;
                                      }
                                  }
							}
							if (busiestVM != null)
							{
								busiestVM.migrate(newTargetHost);
								System.out.println("VM no " + minID + " was migrated to host number" + newTargetHost);
							}						
						}
					}
				}
				}catch(Exception e){
					e.printStackTrace();
				}
			



			
		} catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
	
	}
}
